# Avatar Livestream MVP

Updated scaffold with CI, Vercel config, and mock mode.
